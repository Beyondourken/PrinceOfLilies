﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class TalkDataBaseList : MonoBehaviour  //remove this line and uncomment next line

//public class TalkDataBaseList : ScriptableObject
{             //The scriptable Object where the conversation are stored (TalkDatabase)

    [SerializeField]
    public List<Talk> talkList = new List<Talk>();              //List of conversations

	void Start() 
	{

		talkList.Add(new Talk (1, 101, "Guard", "You can not enter here", "OK", 102, "Sorry", 103, "right oh", 104));
		talkList.Add(new Talk (1, 102, "Guard", "Test 102", "back", 101, "back", 101, "back", 101));
		talkList.Add(new Talk (1, 103, "Guard", "Test 103", "back", 101, "back", 101, "back", 101));
		talkList.Add(new Talk (1, 104, "Guard", "Test 104", "back", 101, "back", 101, "back", 101));


	}

    public Talk getTalkByID(int id)
    {
        for (int i = 0; i < talkList.Count; i++)
        {
            if (talkList[i].talkID == id)
                return talkList[i].getCopy();
        }
        return null;
    }

}
