﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[System.Serializable]
public class Talk
{
	public int talkScene;                                       //scene number
	public int talkID;                                          //identifier for conversation
	public Sprite talkSpeaker;                                  //person speaking
    public string talkSpeech;                                   //what the person is saying
	public string talkResponse1;								//first reply option
	public int talkNext1;										//next conversation if this reply is chosen
	public string talkResponse2;								//Second reply option
	public int talkNext2;										//next conversation if this reply is chosen
	public string talkResponse3;								//Third reply option
	public int talkNext3;										//next conversation if this reply is chosen
   

  
 
    public Talk(){}


	//function to create a instance of the conversation
	public Talk(int scene, int id, string speaker, string speech, string response1, int next1, string response2, int next2,string response3, int next3)  {  //remove and uncomment next line
	//public Talk(int scene, int id, Sprite speaker, string speech, string response1, int next1, string response2, int next2,string response3, int next3)  {
		talkScene = scene;
		talkSpeaker = Resources.Load<Sprite> ("" + speaker); //remove and uncomment next line
	//	talkSpeaker = speaker;
        talkID = id;
		talkSpeech = speech;
		talkResponse1 = response1;
		talkNext1 = next1;
		talkResponse2 = response2;
		talkNext2 = next2;
		talkResponse3 = response3;
		talkNext3 = next3;
    }

    public Talk getCopy()
    {
        return (Talk)this.MemberwiseClone();        
    }   
    
    
}


