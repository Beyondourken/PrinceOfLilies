﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class TalkOnObject : MonoBehaviour                   //Saves the remark in the slot
{
    public Talk talk;                                       //Talk 
    private Text text;                                      //text for the remark
    private Image image;

    void Update()
    {
        text.text = "" + talk.talkSpeech;                     //sets the talkValue         
        image.sprite = talk.talkSpeaker;
      //  GetComponent<ChooseTalk>().talk = talk;
    }

    void Start()
    {
        image = transform.GetChild(0).GetComponent<Image>();
        transform.GetChild(0).GetComponent<Image>().sprite = talk.talkSpeaker;                 //set the sprite of the speaker
        text = transform.GetChild(1).GetComponent<Text>();                                  //get the text(talkValue GameObject) of the remark
    }
}



/*talkSpeaker = speaker;
talkID = id;
talkSpeaker = speaker;
talkSpeech = speech;
talkResponse1 = response1;
talkNext1 = next1;
talkResponse2 = response2;
talkNext2 = next2;
talkResponse3 = response3;
talkNext3 = next3;*/