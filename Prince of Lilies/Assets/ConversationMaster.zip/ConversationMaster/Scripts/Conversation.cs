﻿using UnityEngine;
using System.Collections;
#if UNITY_EDITOR
using UnityEditor;
#endif
using UnityEngine.UI;
using System.Collections.Generic;

public class Conversation : MonoBehaviour

{
	public GameObject talks;
	/*
    //Prefabs
    [SerializeField]
    private GameObject prefabCanvasWithPanel;
    [SerializeField]
    private GameObject prefabTalkSlot;
    [SerializeField]
    private GameObject prefabTalkSlotContainer;
    [SerializeField]
    private GameObject prefabtalk;
    [SerializeField]
    private GameObject prefabPanel;

    //talkdatabase
    [SerializeField]
    private TalkDataBaseList talkDatabase;

    //GameObjects which are alive
    [SerializeField]
    private string conversationTitle;
    [SerializeField]
    private RectTransform PanelRectTransform;
    [SerializeField]
    private Image PanelImage;
    [SerializeField]
    private GameObject SlotContainer;
    [SerializeField]
    private RectTransform SlotContainerRectTransform;
    [SerializeField]
    private GridLayoutGroup SlotGridLayout;
    [SerializeField]
    private RectTransform SlotGridRectTransform;

    //Conversation Settings
    [SerializeField]
    public List<Talk> TalksInConversation = new List<Talk>();
    [SerializeField]
    public int height;
    [SerializeField]
    public int width;
    [SerializeField]
    public bool stackable;
    [SerializeField]
    public static bool conversationOpen;


    //GUI Settings
    [SerializeField]
    public int slotSize;
    [SerializeField]
    public int iconSize;
    [SerializeField]
    public int paddingBetweenX;
    [SerializeField]
    public int paddingBetweenY;
    [SerializeField]
    public int paddingLeft;
    [SerializeField]
    public int paddingRight;
    [SerializeField]
    public int paddingBottom;
    [SerializeField]
    public int paddingTop;
    [SerializeField]
    public int positionNumberX;
    [SerializeField]
    public int positionNumberY;

    InputManager inputManagerDatabase;

    //event delegates 
    public delegate void talkDelegate(Talk talk);
    public static event talkDelegate talkChosen;
   

    public delegate void conversationOpened();
    public static event conversationOpened ConversationOpen;
    public static event conversationOpened AllConversationsClosed;
*/
    void Start()
    {
      this.gameObject.SetActive(true);  ///set to false after testing ****************************************************************

   //   updateTalkList();

    //    inputManagerDatabase = (InputManager)Resources.Load("InputManager");
    }

 /*
    void Update()
    {
        updateTalkIndex();
    }


     public void OnUpdatetalkList()
    {
        updateTalkList();
    }

    public void closeconversation()
    {
        this.gameObject.SetActive(false);
		AllConversationsClosed();
    }

    public void openconversation()
    {
        this.gameObject.SetActive(true);
        if (ConversationOpen != null)
            ConversationOpen();
    }

    public void ChooseTalk(Talk talk)
    {
        if (talkChosen != null)
            talkChosen(talk);
    }




#if UNITY_EDITOR
    [MenuItem("Master System/Create/Conversation")]        //creating the menu talk
    public static void menuTalkCreateconversation()       //create the conversation at start
    {
        GameObject Canvas = null;
        if (GameObject.FindGameObjectWithTag("Canvas") == null)
        {
            GameObject conversation = new GameObject();
            conversation.name = "Conversations";
            Canvas = (GameObject)Instantiate(Resources.Load("Prefabs/Canvas - Conversation") as GameObject);
            Canvas.transform.SetParent(conversation.transform, true);
            GameObject panel = (GameObject)Instantiate(Resources.Load("Prefabs/Panel - Conversation") as GameObject);
            panel.GetComponent<RectTransform>().localPosition = new Vector3(0, 0, 0);
            panel.transform.SetParent(Canvas.transform, true);
            Conversation temp = panel.AddComponent<Conversation>();
            Instantiate(Resources.Load("Prefabs/EventSystem") as GameObject);
            panel.AddComponent<ConversationDesign>();
            temp.getPrefabs();
        }
        else
        {
            GameObject panel = (GameObject)Instantiate(Resources.Load("Prefabs/Panel - Conversation") as GameObject);
            panel.transform.SetParent(GameObject.FindGameObjectWithTag("Canvas").transform, true);
            panel.GetComponent<RectTransform>().localPosition = new Vector3(0, 0, 0);
            Conversation temp = panel.AddComponent<Conversation>();
            panel.AddComponent<ConversationDesign>();
            temp.getPrefabs();
        }
    }
#endif

    public void setImportantVariables()
    {
        PanelRectTransform = GetComponent<RectTransform>();
        SlotContainer = transform.GetChild(1).gameObject;
        SlotGridLayout = SlotContainer.GetComponent<GridLayoutGroup>();
        SlotGridRectTransform = SlotContainer.GetComponent<RectTransform>();
    }

    public void getPrefabs()
    {
        if (prefabCanvasWithPanel == null)
            prefabCanvasWithPanel = Resources.Load("Prefabs/Canvas - Conversation") as GameObject;
        if (prefabTalkSlot == null)
            prefabTalkSlot = Resources.Load("Prefabs/Slot - Conversation") as GameObject;
        if (prefabTalkSlotContainer == null)
            prefabTalkSlotContainer = Resources.Load("Prefabs/Slots - Conversation") as GameObject;
        if (prefabtalk == null)
            prefabtalk = Resources.Load("Prefabs/Talk") as GameObject;
        if (talkDatabase == null)
            talkDatabase = (TalkDataBaseList)Resources.Load("TalkDatabase");
        if (prefabPanel == null)
            prefabPanel = Resources.Load("Prefabs/Panel - Conversation") as GameObject;

        setImportantVariables();
        setDefaultSettings();
        adjustConversationSize();
        updateSlotAmount(width, height);
        updateSlotSize();
        updatePadding(paddingBetweenX, paddingBetweenY);

    }

    public void updateTalkList()
    {
        TalksInConversation.Clear();
        for (int i = 0; i < SlotContainer.transform.childCount; i++)
        {
            Transform trans = SlotContainer.transform.GetChild(i);
            if (trans.childCount != 0)
            {
                TalksInConversation.Add(trans.GetChild(0).GetComponent<TalkOnObject>().talk);
            }
        }

    }

   

    public void setDefaultSettings()
    {
       
            height = 5;
            width = 5;

            slotSize = 50;
            iconSize = 45;

            paddingBetweenX = 5;
            paddingBetweenY = 5;
            paddingTop = 35;
            paddingBottom = 10;
            paddingLeft = 10;
            paddingRight = 10;
      
    }

    public void adjustConversationSize()
    {
        int x = (((width * slotSize) + ((width - 1) * paddingBetweenX)) + paddingLeft + paddingRight);
        int y = (((height * slotSize) + ((height - 1) * paddingBetweenY)) + paddingTop + paddingBottom);
        PanelRectTransform.sizeDelta = new Vector2(x, y);

        SlotGridRectTransform.sizeDelta = new Vector2(x, y);
    }

    public void updateSlotAmount(int width, int height)
    {
        if (prefabTalkSlot == null)
            prefabTalkSlot = Resources.Load("Prefabs/Slot - Conversation") as GameObject;

        if (SlotContainer == null)
        {
            SlotContainer = (GameObject)Instantiate(prefabTalkSlotContainer);
            SlotContainer.transform.SetParent(PanelRectTransform.transform);
            SlotContainerRectTransform = SlotContainer.GetComponent<RectTransform>();
            SlotGridRectTransform = SlotContainer.GetComponent<RectTransform>();
            SlotGridLayout = SlotContainer.GetComponent<GridLayoutGroup>();
        }

        if (SlotContainerRectTransform == null)
            SlotContainerRectTransform = SlotContainer.GetComponent<RectTransform>();

        SlotContainerRectTransform.localPosition = Vector3.zero;

        List<Talk> talksToMove = new List<Talk>();
        List<GameObject> slotList = new List<GameObject>();
        foreach (Transform child in SlotContainer.transform)
        {
            if (child.tag == "Slot") { slotList.Add(child.gameObject); }
        }

        while (slotList.Count > width * height)
        {
            GameObject go = slotList[slotList.Count - 1];
            TalkOnObject talkInSlot = go.GetComponentInChildren<TalkOnObject>();
            if (talkInSlot != null)
            {
                talksToMove.Add(talkInSlot.talk);
                TalksInConversation.Remove(talkInSlot.talk);
            }
            slotList.Remove(go);
            DestroyImmediate(go);
        }

        if (slotList.Count < width * height)
        {
            for (int i = slotList.Count; i < (width * height); i++)
            {
                GameObject Slot = (GameObject)Instantiate(prefabTalkSlot);
                Slot.name = (slotList.Count + 1).ToString();
                Slot.transform.SetParent(SlotContainer.transform);
                slotList.Add(Slot);
            }
        }

        if (talksToMove != null && TalksInConversation.Count < width * height)
        {
            foreach (Talk i in talksToMove)
            {
                addTalkToConversation(i.talkID);
            }
        }

        setImportantVariables();
    }

    public void updateSlotAmount()
    {

        if (prefabTalkSlot == null)
            prefabTalkSlot = Resources.Load("Prefabs/Slot - Conversation") as GameObject;

        if (SlotContainer == null)
        {
            SlotContainer = (GameObject)Instantiate(prefabTalkSlotContainer);
            SlotContainer.transform.SetParent(PanelRectTransform.transform);
            SlotContainerRectTransform = SlotContainer.GetComponent<RectTransform>();
            SlotGridRectTransform = SlotContainer.GetComponent<RectTransform>();
            SlotGridLayout = SlotContainer.GetComponent<GridLayoutGroup>();
        }

        if (SlotContainerRectTransform == null)
            SlotContainerRectTransform = SlotContainer.GetComponent<RectTransform>();
        SlotContainerRectTransform.localPosition = Vector3.zero;

        List<Talk> talksToMove = new List<Talk>();
        List<GameObject> slotList = new List<GameObject>();
        foreach (Transform child in SlotContainer.transform)
        {
            if (child.tag == "Slot") { slotList.Add(child.gameObject); }
        }

        while (slotList.Count > width * height)
        {
            GameObject go = slotList[slotList.Count - 1];
            TalkOnObject talkInSlot = go.GetComponentInChildren<TalkOnObject>();
            if (talkInSlot != null)
            {
                talksToMove.Add(talkInSlot.talk);
                TalksInConversation.Remove(talkInSlot.talk);
            }
            slotList.Remove(go);
            DestroyImmediate(go);
        }

        if (slotList.Count < width * height)
        {
            for (int i = slotList.Count; i < (width * height); i++)
            {
                GameObject Slot = (GameObject)Instantiate(prefabTalkSlot);
                Slot.name = (slotList.Count + 1).ToString();
                Slot.transform.SetParent(SlotContainer.transform);
                slotList.Add(Slot);
            }
        }

        if (talksToMove != null && TalksInConversation.Count < width * height)
        {
            foreach (Talk i in talksToMove)
            {
                addTalkToConversation(i.talkID);
            }
        }

        setImportantVariables();
    }

    public void updateSlotSize(int slotSize)
    {
        SlotGridLayout.cellSize = new Vector2(slotSize, slotSize);

        updateTalkSize();
    }

    public void updateSlotSize()
    {
        SlotGridLayout.cellSize = new Vector2(slotSize, slotSize);

        updateTalkSize();
    }

    void updateTalkSize()
    {
        for (int i = 0; i < SlotContainer.transform.childCount; i++)
        {
            if (SlotContainer.transform.GetChild(i).childCount > 0)
            {
                SlotContainer.transform.GetChild(i).GetChild(0).GetComponent<RectTransform>().sizeDelta = new Vector2(slotSize, slotSize);
                SlotContainer.transform.GetChild(i).GetChild(0).GetChild(2).GetComponent<RectTransform>().sizeDelta = new Vector2(slotSize, slotSize);
            }

        }
    }

    public void updatePadding(int spacingBetweenX, int spacingBetweenY)
    {
        SlotGridLayout.spacing = new Vector2(paddingBetweenX, paddingBetweenY);
        SlotGridLayout.padding.bottom = paddingBottom;
        SlotGridLayout.padding.right = paddingRight;
        SlotGridLayout.padding.left = paddingLeft;
        SlotGridLayout.padding.top = paddingTop;
    }

    public void updatePadding()
    {
        SlotGridLayout.spacing = new Vector2(paddingBetweenX, paddingBetweenY);
        SlotGridLayout.padding.bottom = paddingBottom;
        SlotGridLayout.padding.right = paddingRight;
        SlotGridLayout.padding.left = paddingLeft;
        SlotGridLayout.padding.top = paddingTop;
    }

    public void addAllTalksToConversation()
    {
        for (int k = 0; k < TalksInConversation.Count; k++)
        {
            for (int i = 0; i < SlotContainer.transform.childCount; i++)
            {
                if (SlotContainer.transform.GetChild(i).childCount == 0)
                {
                    GameObject talk = (GameObject)Instantiate(prefabtalk);
                    talk.GetComponent<TalkOnObject>().talk = TalksInConversation[k];
                    talk.transform.SetParent(SlotContainer.transform.GetChild(i));
                    talk.GetComponent<RectTransform>().localPosition = Vector3.zero;
					talk.transform.GetChild(0).GetComponent<Image>().sprite = TalksInConversation[k].talkSpeaker;
                 // 	talk.transform.GetChild(0).GetComponent<string>() = TalksInConversation[k].talkSpeech;
				//	talk.transform.GetChild(2).GetComponent<string>() = TalksInConversation[k].talkResponse1;
				//	talk.transform.GetChild(3).GetComponent<string>() = TalksInConversation[k].talkResponse2;
				//	talk.transform.GetChild(4).GetComponent<string>() = TalksInConversation[k].talkResponse3;
                    updateTalkSize();
                    break;
                }
            }
        }
        stackableSettings();
    }


    public bool checkIfTalkAllreadyExist(int talkID, int talkValue)
    {
        updateTalkList();
        int stack;
        for (int i = 0; i < TalksInConversation.Count; i++)
        {
            if (TalksInConversation[i].talkID == talkID)
            {
                stack = TalksInConversation[i].talkValue + talkValue;
                if (stack <= TalksInConversation[i].maxStack)
                {
                    TalksInConversation[i].talkValue = stack;
                    GameObject temp = getTalkGameObject(TalksInConversation[i]);
                    if (temp != null && temp.GetComponent<Consumetalk>().duplication != null)
                        temp.GetComponent<Consumetalk>().duplication.GetComponent<TalkOnObject>().Talk.talkValue = stack;
                    return true;
                }
            }
        }
        return false;
    }


    public void addTalkToConversation(int id)
    {
        for (int i = 0; i < SlotContainer.transform.childCount; i++)
        {
            if (SlotContainer.transform.GetChild(i).childCount == 0)
            {
                GameObject talk = (GameObject)Instantiate(prefabtalk);
                talk.GetComponent<TalkOnObject>().talk = talkDatabase.getTalkByID(id);
                talk.transform.SetParent(SlotContainer.transform.GetChild(i));
                talk.GetComponent<RectTransform>().localPosition = Vector3.zero;
				talk.transform.GetChild(0).GetComponent<Image>().sprite = TalksInConversation[0].talkSpeaker;
			//	talk.transform.GetChild(1).GetComponent<string>() = TalksInConversation[k].talkSpeech;
			//	talk.transform.GetChild(2).GetComponent<string>() = TalksInConversation[k].talkResponse1;
			//	talk.transform.GetChild(3).GetComponent<string>() = TalksInConversation[k].talkResponse2;
			//	talk.transform.GetChild(4).GetComponent<string>() = TalksInConversation[k].talkResponse3;
                break;
            }
        }

        stackableSettings();
        updateTalkList();

    }

    public GameObject addTalkToconversation(int id, int value)
    {
        for (int i = 0; i < SlotContainer.transform.childCount; i++)
        {
            if (SlotContainer.transform.GetChild(i).childCount == 0)
            {
                GameObject talk = (GameObject)Instantiate(prefabtalk);
                TalkOnObject talkOnObject = talk.GetComponent<TalkOnObject>();
                talkOnObject.talk = talkDatabase.getTalkByID(id);
                talk.transform.SetParent(SlotContainer.transform.GetChild(i));
                talk.GetComponent<RectTransform>().localPosition = Vector3.zero;
                talk.transform.GetChild(0).GetComponent<Image>().sprite = talkOnObject.talk.talkSpeaker;
             //   talkOnObject.talk.indexTalkInList = TalksInConversation.Count - 1;
                if (inputManagerDatabase == null)
                    inputManagerDatabase = (InputManager)Resources.Load("InputManager");
                return talk;
            }
        }

        stackableSettings();
        updateTalkList();
        return null;

    }

    public void addTalkToconversationStorage(int talkID, int value)
    {

        for (int i = 0; i < SlotContainer.transform.childCount; i++)
        {
            if (SlotContainer.transform.GetChild(i).childCount == 0)
            {
                GameObject talk = (GameObject)Instantiate(prefabtalk);
                TalkOnObject talkOnObject = talk.GetComponent<TalkOnObject>();
                talkOnObject.talk = talkDatabase.getTalkByID(talkID);
               
                talk.transform.SetParent(SlotContainer.transform.GetChild(i));
                talk.GetComponent<RectTransform>().localPosition = Vector3.zero;
             //   talkOnObject.talk.indexTalkInList = 999;
                if (inputManagerDatabase == null)
                    inputManagerDatabase = (InputManager)Resources.Load("InputManager");
                updateTalkSize();
                stackableSettings();
                break;
            }
        }
        stackableSettings();
        updateTalkList();
    }

    public void updateIconSize(int iconSize)
    {
        for (int i = 0; i < SlotContainer.transform.childCount; i++)
        {
            if (SlotContainer.transform.GetChild(i).childCount > 0)
            {
                SlotContainer.transform.GetChild(i).GetChild(0).GetChild(0).GetComponent<RectTransform>().sizeDelta = new Vector2(iconSize, iconSize);
            }
        }
        updateTalkSize();

    }

    public void updateIconSize()
    {
        for (int i = 0; i < SlotContainer.transform.childCount; i++)
        {
            if (SlotContainer.transform.GetChild(i).childCount > 0)
            {
                SlotContainer.transform.GetChild(i).GetChild(0).GetChild(0).GetComponent<RectTransform>().sizeDelta = new Vector2(iconSize, iconSize);
            }
        }
        updateTalkSize();

    }

    public void stackableSettings(bool stackable, Vector3 posi)
    {
        for (int i = 0; i < SlotContainer.transform.childCount; i++)
        {
            if (SlotContainer.transform.GetChild(i).childCount > 0)
            {
                TalkOnObject talk = SlotContainer.transform.GetChild(i).GetChild(0).GetComponent<TalkOnObject>();
              //  if (talk.talk.maxStack > 1)
             //   {
                    RectTransform textRectTransform = SlotContainer.transform.GetChild(i).GetChild(0).GetChild(1).GetComponent<RectTransform>();
                    Text text = SlotContainer.transform.GetChild(i).GetChild(0).GetChild(1).GetComponent<Text>();
                    text.text = "" + talk.talk.talkSpeech;
                    text.enabled = stackable;
                    textRectTransform.localPosition = posi;
            //    }
            }
        }
    }


    public void deleteAlltalks()
    {
        for (int i = 0; i < SlotContainer.transform.childCount; i++)
        {
            if (SlotContainer.transform.GetChild(i).childCount != 0)
            {
                Destroy(SlotContainer.transform.GetChild(i).GetChild(0).gameObject);
            }
        }
    }

    public List<Talk> getTalkList()
    {
        List<Talk> theList = new List<Talk>();
        for (int i = 0; i < SlotContainer.transform.childCount; i++)
        {
            if (SlotContainer.transform.GetChild(i).childCount != 0)
                theList.Add(SlotContainer.transform.GetChild(i).GetChild(0).GetComponent<TalkOnObject>().talk);
        }
        return theList;
    }

    public void stackableSettings()
    {
        for (int i = 0; i < SlotContainer.transform.childCount; i++)
        {
            if (SlotContainer.transform.GetChild(i).childCount > 0)
            {
                TalkOnObject talk = SlotContainer.transform.GetChild(i).GetChild(0).GetComponent<TalkOnObject>();
            //    if (talk.talk.maxStack > 1)
             //   {
                    RectTransform textRectTransform = SlotContainer.transform.GetChild(i).GetChild(0).GetChild(1).GetComponent<RectTransform>();
                    Text text = SlotContainer.transform.GetChild(i).GetChild(0).GetChild(1).GetComponent<Text>();
                    text.text = "" + talk.talk.talkSpeech;
                    text.enabled = stackable;
                    textRectTransform.localPosition = new Vector3(positionNumberX, positionNumberY, 0);
            //    }
            //    else
            //    {
            //        Text text = SlotContainer.transform.GetChild(i).GetChild(0).GetChild(1).GetComponent<Text>();
              //      text.enabled = false;
              //  }
            }
        }

    }

    public GameObject getTalkGameObjectByID(Talk talk)
    {
        for (int k = 0; k < SlotContainer.transform.childCount; k++)
        {
            if (SlotContainer.transform.GetChild(k).childCount != 0)
            {
                GameObject talkGameObject = SlotContainer.transform.GetChild(k).GetChild(0).gameObject;
                Talk talkObject = talkGameObject.GetComponent<TalkOnObject>().talk;
                if (talkObject.talkID.Equals(talk.talkID))
                {
                    return talkGameObject;
                }
            }
        }
        return null;
    }

    public GameObject getTalkGameObject(Talk talk)
    {
        for (int k = 0; k < SlotContainer.transform.childCount; k++)
        {
            if (SlotContainer.transform.GetChild(k).childCount != 0)
            {
                GameObject talkGameObject = SlotContainer.transform.GetChild(k).GetChild(0).gameObject;
                Talk talkObject = talkGameObject.GetComponent<TalkOnObject>().talk;
                if (talkObject.Equals(talk))
                {
                    return talkGameObject;
                }
            }
        }
        return null;
    }



    public void changeConversationPanelDesign(Image image)
    {
        Image conversationDesign = transform.GetChild(0).GetChild(0).GetComponent<Image>();
        conversationDesign.sprite = (Sprite)image.sprite;
        conversationDesign.color = image.color;
        conversationDesign.material = image.material;
        conversationDesign.type = image.type;
        conversationDesign.fillCenter = image.fillCenter;
    }

    public void deleteTalk(Talk talk)
    {
        for (int i = 0; i < TalksInConversation.Count; i++)
        {
            if (talk.Equals(TalksInConversation[i]))
                TalksInConversation.RemoveAt(talk.talkID);
        }
    }

    

    public void deleteTalkFromconversation(Talk talk)
    {
        for (int i = 0; i < TalksInConversation.Count; i++)
        {
            if (talk.Equals(TalksInConversation[i]))
                TalksInConversation.RemoveAt(i);
        }
    }

    public void deleteTalkFromconversationWithGameObject(Talk talk)
    {
        for (int i = 0; i < TalksInConversation.Count; i++)
        {
            if (talk.Equals(TalksInConversation[i]))
            {
                TalksInConversation.RemoveAt(i);
            }
        }

        for (int k = 0; k < SlotContainer.transform.childCount; k++)
        {
            if (SlotContainer.transform.GetChild(k).childCount != 0)
            {
                GameObject talkGameObject = SlotContainer.transform.GetChild(k).GetChild(0).gameObject;
                Talk talkObject = talkGameObject.GetComponent<TalkOnObject>().talk;
                if (talkObject.Equals(talk))
                {
                    Destroy(talkGameObject);
                    break;
                }
            }
        }
    }

    public int getPositionOfTalk(Talk talk)
    {
        for (int i = 0; i < SlotContainer.transform.childCount; i++)
        {
            if (SlotContainer.transform.GetChild(i).childCount != 0)
            {
                Talk talk2 = SlotContainer.transform.GetChild(i).GetChild(0).GetComponent<TalkOnObject>().talk;
                if (talk.Equals(talk2))
                    return i;
            }
        }
        return -1;
    }

    public void addTalkToConversation(int ignoreSlot, int talkID, int talkValue)
    {

        for (int i = 0; i < SlotContainer.transform.childCount; i++)
        {
            if (SlotContainer.transform.GetChild(i).childCount == 0 && i != ignoreSlot)
            {
                GameObject talk = (GameObject)Instantiate(prefabtalk);
                TalkOnObject talkOnObject = talk.GetComponent<TalkOnObject>();
                talkOnObject.talk = talkDatabase.getTalkByID(talkID);
               // if (talkOnObject.talk.talkValue < talkOnObject.talk.maxStack && talkValue <= talkOnObject.talk.maxStack)
               // talkOnObject.talk.talkSpeech = talkSpeech;
               // else
               //     talkOnObject.talk.talkValue = 1;
                talk.transform.SetParent(SlotContainer.transform.GetChild(i));
                talk.GetComponent<RectTransform>().localPosition = Vector3.zero;
             //   talkOnObject.talk.indexTalkInList = 999;
                updateTalkSize();
                stackableSettings();
                break;
            }
        }
        stackableSettings();
        updateTalkList();
    }




    public void updateTalkIndex()
    {
        for (int i = 0; i < TalksInConversation.Count; i++)
        {
    //        TalksInConversation[i].indexTalkInList = i;
        }
    }
     */
}
