﻿using UnityEngine;
using System.Collections;
#if UNITY_EDITOR
using UnityEditor;
#endif


public class CreateTalkDatabase
{
    public static TalkDataBaseList asset;                                                  //The List of all Conversations

#if UNITY_EDITOR
  /*  public static TalkDataBaseList createTalkDatabase()                                    //creates a new TalkDatabase(new instance)
    {
       asset = ScriptableObject.CreateInstance<TalkDataBaseList>();                       //of the ScriptableObject ConversationTalkList

        AssetDatabase.CreateAsset(asset, "Assets/ConversationMaster/Resources/TalkDatabase.asset");            //in the Folder Assets/Resources/TalkDatabase.asset
        AssetDatabase.SaveAssets();                                                         //and then saves it there
        asset.talkList.Add(new Talk());
        return asset;
    }
    */
#endif



}
